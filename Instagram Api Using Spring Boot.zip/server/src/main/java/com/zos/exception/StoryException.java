package com.zos.exception;

import com.zos.model.Story;

public class StoryException extends Exception{

	public StoryException() {
		// TODO Auto-generated constructor stub
	}
	
	public StoryException(String message) {
		super();
	}
}
