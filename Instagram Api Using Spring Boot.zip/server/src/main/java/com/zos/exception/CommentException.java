package com.zos.exception;

public class CommentException extends Exception {
	
	public CommentException() {
		// TODO Auto-generated constructor stub
	}
	
	public CommentException(String message) {
		super(message);
	}

}
